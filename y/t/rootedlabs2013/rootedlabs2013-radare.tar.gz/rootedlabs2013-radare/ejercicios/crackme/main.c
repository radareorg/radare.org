#include <stdio.h>
#include <string.h>

int main() {
	int ret;
	char buf[32];
	fprintf (stderr, "password: ");
	fgets (buf, sizeof (buf), stdin);
	if (feof (stdin)) return 1;
	buf[strlen (buf)-1] = 0;
	ret = strcmp ("r4l4bk3y", buf);
	printf ("%s\n", ret? "err": "ok");
	return ret;
}
