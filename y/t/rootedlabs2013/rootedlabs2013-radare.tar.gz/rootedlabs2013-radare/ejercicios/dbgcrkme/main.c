#include <stdio.h>
#include <string.h>

static const char *pass () {
	static char ret[10];
	int i;
	memcpy (ret, "\x4a\x57\x57\x4c\x54\x59\x5a\x09\x0b\x38", 10);
	for (i=0; i<sizeof (ret); i++)
		ret[i] ^= 0x38;
	return ret;
}

int main() {
	int ret;
	char buf[32];
	fprintf (stderr, "password: ");
	fgets (buf, sizeof (buf), stdin);
	if (feof (stdin)) return 1;
	buf[strlen (buf)-1] = 0;
	ret = strcmp (pass (), buf);
	printf ("%s\n", ret? "err": "ok");
	return ret;
}
