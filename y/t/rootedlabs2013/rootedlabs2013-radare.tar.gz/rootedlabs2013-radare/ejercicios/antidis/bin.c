#include <stdio.h>
#include <string.h>

int main () {
	char buf[64];
	fprintf (stderr, "enter password: ");
	__asm__ __volatile__ (".byte 0x56;add $0x04eb9090, %esi\n.byte 0xeb,0xfc,0xa3,0x66\n.byte 0x5e;");
	read (0, buf, 128);
	__asm__ __volatile__ (".byte 0x56;add $0x04eb6690, %esi\n.byte 0xeb,0xfc,0xa3,0x66\n.byte 0x5e;");
	printf ("%s\n", (buf[0]+buf[1]=='h'+'i')? "ok": "err");
	return 0;
}
