#!/bin/sh

if [ -z "$1" ]; then
	echo "Usage: $0 [filename]"
	exit 1
fi
tf=""
add() { tf="${tf} $1" ; }
get() { f=`basename $1` ; cp $1 . ; add $f ; }
fini() { echo rm ${tf} 2>/dev/null; rm -f ${tf} ; }

header() {
	printf GZFW
}

piece() {
	[ "$3" = "+" ] && add $2.gz
	gzip -9 < $2 > $2.gz
	add $2.gz
	rax2 -s $1
	sz=`ls -l $2.gz |awk '{print $5}'`
	rax2 -sn $sz
	rax2 -s `rahash2 -qa crc32 $2.gz`
	cat $2.gz
	rm -f $2.gz
}

footer() {
	printf GZFW
}

clean() {
	echo $tf > /dev/stderr
	rm -f *.gz
}

(
trap fini 2 
	header

	piece 01 header.txt

	get ../crackme/crackme
	piece 02 crackme

	rabin2 -c elf:cc lilbin
	piece 02 lilbin +

	uname -a > uname.txt
	piece 03 uname.txt +

	piece 03 zebra.jpg +

	footer
fini
) > $1
echo DONE > /dev/stderr
