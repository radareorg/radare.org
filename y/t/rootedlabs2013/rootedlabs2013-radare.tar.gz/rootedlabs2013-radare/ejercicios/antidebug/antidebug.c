#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static inline isDebuggerPresent () {
        const char *a = getenv("SUDO_COMMAND");
        if (!a) a = getenv ("_");
	__asm__ __volatile__ (".byte 0x56;add $0x04eb9090, %esi\n.byte 0xeb,0xfc,0xa3,0x66\n.byte 0x5e;");
	if (!a) return prctl (PR_SET_DUMPABLE, 0)? 0: 1;
	return (strstr (a,"tr") || \
		strstr (a,"gd") || \
		strstr (a,"rad")|| \
		strstr (a,"r2"));
}

int main() {
	printf (isDebuggerPresent ()?
		"Do not debug me! I like my own bugs!\n":
		"Did you tried to debug me?\n");
	return 0;
}
