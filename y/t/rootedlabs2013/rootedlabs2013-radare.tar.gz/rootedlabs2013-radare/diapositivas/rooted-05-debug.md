% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(5/6)
% ----------------------------------------------------- %
#Depurando programas

Una vez asimilados los conceptos de como usar radare como editor hexadecimal y analizador de codigo, veremos que podremos aplicar los mismos conocimientos para depurar programas.

Durante este apartado usaremos los subcomandos de 'd' que nos permitiran controlar el debugger.

Hay que tener en cuenta que la API de debug de radare es independiente de plataforma, al igual que el resto de apis. Esto nos permite automatizar la depuración (unpacking, debugging, fuzzing) con scripts o programas escritos en C/Vala..

% ----------------------------------------------------- %
#Iniciando el proceso

Para empezar debemos lanzar un procesos o atacharnos a ellos. Cabe destacar que depurar en radare implica no solo usar el plugin de IO correspondiente para que pueda leer/escribir memoria, sino tambien configurar los handlers, definir pid, realizar el fork, etc..

Todo esto queda simplificado con una sola flag: '-d'

	$ r2 -d ls                $ r2 -d ./ls
	$ r2 -d 1924              $ r2 -d `pidof firefox`
	$ r2 ptrace://20138       $ r2 -d "ls /"

Dentro de la shell, podremos usar 'dp' para seleccionar o listar el proceso que estamos depurando, sus hijos y sus hilos de ejecución.

% ----------------------------------------------------- %
#Inicio avanzado

A veces nos interesará lanzar los programas más de una vez con parametros similares o con un entorno predefinido. Radare nos ofrece la herramient 'rarun2' que nos permite definir varios parametros para lanzar el proceso:

 - chdir
 - chroot
 - port binding
 - diferente UID/GID
 - precargar librerias
 - variables de entorno
 - stdin/stdout desde ficheros
 - detener despues de N segundos

	$ rarun2 listen=8080 program=/bin/sh

% ----------------------------------------------------- %
#Bootstrap
Asi es como el sistema operativo carga los programas. Utilizando la variable dbg.bep podemos escoger en que punto detenernos como punto de partida.

	+--------+    +--------+
	| execve | -->| loader |
	+--------+    +---v----+
	                  |    +-------------+      +------+
	                  |----| constructor |  .-->| init |
	                  |    +-------------+  |   +------+
	                  |                     |
	                  |    +-------+        |   +------+
	                  |----| entry |--------+-->| main |
	                  |    +-------+        |   +------+
	                  |                     |       
	                  |    +------------+   |   +------+
	                  `----| destructor |   `-->| fini |
	                       +------------+       +------+
% ----------------------------------------------------- %
#Break entry..
Para lanzar el depurador deberemos usar la flag '-d'.
	$ r2 -d ./a.out   # depurando un programa en el directorio actual.
	$ r2 -d ls        # iniciando la depuración de 'ls' en $PATH
	$ r2 -d 'ls /'    # pasando argumentos al programa

Escojamos donde queremos empezar a depurar con la variable dbg.bep:

	$ r2 -e dbg.bep=loader -d ls
	$ r2 -e dbg.bep=entry -d ls
	$ r2 -e dbg.bep=main -d ls
	$ r2 -e dbg.bep=0x8048620 -d ls

Seria un equivalente a:

	$ r2 -c'dcu main' -d ls
% ----------------------------------------------------- %
#Elementos de un programa
	                                            _________
	+-----------+   +---------------------+    |         |
	| registros | --| estado del programa | <--| profile |________________
	+-----------+   +---------------------+    |________                  |
	 +---------+  --.                                 |                   |
	 |  codigo |    |                   ___________   | =pc rip           |
	 +---------+    |                  |           |  | =sp rsp           |
	 +--------+     |   +---------+    | permisos, |  | gpr rax .64 8 0   |
	 |  pila  |     >-- | memoria | <--| segmentos |  | gpr rbx .64 16 0  |
	 +--------+     |   +---------+    | secciones |  | gpr rflags .64 96 |
	 +--------+     |                  |___________|  | seg cs .64  152 0 |
	 |  heap  |     |                                 |___________________|
	 +--------+   --`
	 +--------+     +-------------------------------------------+
	 |  meta  |   --| /proc, files, threads, status, signals,.. |
	 +--------+     +-------------------------------------------+

% ----------------------------------------------------- %
#Paso a paso
Si la plataforma no soporta stepping (mips) deberemos usar dbg.swstep

 - instrucción a instrucción (ds)
	0x8049520  eip:  mov eax, 33  ----.  single step
	0x8049525        call 0x80497b8 <-`

 - saltando calls (dso)
	0x804951d        push ecx  ----------.   step over
	0x8049520        mov eax, 33  ---. <-`
	0x8049525  eip:  call 0x80497b8   )      step over
	0x8049520        cmp eax, 0    <-`

 - ignorar N instrucciones (dss)
	0x8049525  eip:  call 0x80497b8 -.
	0x8049528        cmp eax, 0       |
	0x8049528        jz 0x8049712     |  skip 5
	0x8049525        push 0x804ab70   |
	0x8049520        cmp eax, 0    <-`

% ----------------------------------------------------- %
#Mapas de memoria
Con 'dm' podemos ver y manipular los mapas de memoria del proceso.

Esto puede sernos de gran utilidad para entender que librerias estan cargadas, en que punto de ejecución nos encontramos y usar la MMU para detener la ejecución cuando el programa quiera leer/escribir/ejecutar cierta página de memoria (4096)

En el entrypoint del programa veremos que las librerias de las que depende no están aún cargadas. Deberemos detenernos en main o en alguna syscall para tenerlas listas.

Con 'dmd' y 'dml' podemos volcar a disco y recargar el segmento de memoria actual.

* ejemplo *

% ----------------------------------------------------- %
#Registros
El programa (thread) mantiene su estado en los registros. Estos pueden ser manipulados con el comando 'dr'.

	> dr       # mostrar registros
	> dr=      # '' en horizontal
	> .dr*     # cargamos las flags
	> dr eip=0x803840
	> dr eax=0 # cambiamos el valor
	> dr?rax   # leer el valor de rax

Los registros se mapean en memoria y se usa un profile para parsear sus valores.

	> drp      # muestra el profile
% ----------------------------------------------------- %
#Continuar la ejecución
Con el comando 'dc' reanudaremos la ejecución del proceso.

 - continuar hasta que termine o salte una excepcion (dc)
 - '' hasta un punto (dcu)
 - '' hasta una syscall (dcs)
 - '' hasta que se haga un fork (dcf)
 - '' hasta que se ejecute un call (dcc)
 - '' hasta llegar al programa (dcp)

	> dcu main
	> dcs write

% ----------------------------------------------------- %
#Breakpoints

Para definir puntos de parada usaremos el comando 'db'.

	> db main      # añadir breakpoint en main
	> dc           # continuar ejecución
	> db-main      # eliminar breakpoint

Con el comando 'dsi' podemos definir condiciones de parada más complejas.

	> "dsi eax==3,ecx>0"

NOTA: Aún no es posible usar los breakpoints por hardware tal como ya hacía radare1. Esto estará implementado para antes de r2-1.0

% ----------------------------------------------------- %
#Backtrace

Con el comando 'dbt' analizaremos la pila en busca de direcciones de codigo siguiendo las estructuras de los 'stack frames' con tal de saber desde donde venimos.

En casos de corrupcion de pila, puede que esta información no nos sea muy util, asi que podemos especificarle un numero puntero base como parámetro.

Asimismo, el comando 'ad @ ebp' analizará la pila y nos mostrará qué tipo de datos hay y cuales son punteros a datos, strings, etc..

	$ r2 -d ls
	> ad@esp
	> adk

% ----------------------------------------------------- %
#Depurando en modo visual

El modo visual con el depurador nos mostrará el estado de los registros y la pila. Tendremos a nuestra disposición nuevos keybindings:

	.    seek program counter
	s    ejecutar una instrucción
	S    ejecutar una instrucion o parar después del call
	b    definir/borrar breakpoint en el cursor

Podemos definir comandos a ejecutar con las teclas de función mediante las variables 'e key.f..'

% ----------------------------------------------------- %
#Para acabar...

El debugger de r2 no nos ofrece un control tan completo como radare1.. de momento, pero espero poder dedicarle algo de tiempo y importar más código de radare1 para añadir soporte de inyección de código, breakpoints por hardware, manipulacion de filedescriptors, etc..

Al igual que el análisis; las funcionalidades actuales són más que suficientes para la mayoria de casos de uso que nos podamos encontrar.

En caso contrario siempre podemos usar radare1 :)

% ----------------------------------------------------- %
#Ejercicios

Vamos a realizar algún ejercicio práctico usando el debugger para solucionar algunos problemas que he preparado para la ocasión...

* solucionar el crackme con el depurador

* saltar trucos anti-depuración
