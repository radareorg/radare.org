% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(3/6)
% ----------------------------------------------------- %
#Manejo por linea de comandos

Una de las características más notables y temidas de radare es la sintaxis de los comandos. 

Durante éste capitulo entenderemos la logica que se esconde detrás de los comandos y veremos como manejarnos en la shell para realizar varias tareas sobre ficheros binarios.

La shell nos permite interactuar con todas las funcionalidades del programa. Nos será de gran ayuda, no tan solo para tener una interfaz en linea, sino para automatizar tareas sin usar la API.

Empecemos!

% ----------------------------------------------------- %
#El prompt
Al iniciar radare se nos presenta un prompt indicando el offset donde estamos.
	$ r2 -
	[0x00000000]>

El argumento '-', es un alias para malloc://512. r2 -L lista los plugins de IO
A partir de ahora en adelante usaremos '$' como simbolo de la shell del sistema y '>' como simbolo de la shell de radare.

Si introducimos '?' veremos la lista de los comandos soportados. Para obtener la ayuda de cada comando, simplemente hay que escribir '?' al final de cada comando. Los comandos se separan por el carácter ';'.
	> ?;p?;c?

Al igual que con readline (no es readline), podemos movernos por el historial de comandos con las flechas y autocompletar con el tabulador.

% ----------------------------------------------------- %
#Evaluando expresiones

Para obtener la ayuda del comando '?' debemos teclear '???'.

Existen varios subcomandos dentro de '?' que pueden ser utiles para calcular operaciones o interactuar con el usuario.

	> ? 33+2
	35 0x23 043 0000:0023 35 00100011 35.0 0.000000

Podemos listar las variables '$' con el comando '?$?'. Éstas son manejadas internamente por radare y utilizables desde cualquier expresion evaluable.

	> ?v ${asm.bits}

% ----------------------------------------------------- %
#Entrecomillados

Las comillas evitan que se evaluen caracteres especiales como '@', '|', ';', ...

	> ?e Hello @ World
	> "?e Hello @ World"

Puede sernos util...

 - buscar strings    "/ hello@world"
 - comentarios       "CC hehe|hoho"
 - escribir string     "w ola@ke|ase;"
 - echo ?e             "?e Contactadme @trufae"

% ----------------------------------------------------- %
#Mostrando datos

El comando 'p' nos permite mostrar la información del bloque actual en el formato deseado.
	> px         # hexdump (alias: 'x')
	> pd         # desensamblado

Si pulsamos '<enter>' con una linea vacia ejecutaremos el último comando de print pero desplazandonos al bloque siguiente.

Al ser un editor hexadecimal basado en bloques deberemos especificar el tamaño como argumento o definiendo el tamaño con 'b' o '@!'. Usaremos 's' para cambiar  y cambiar nuestra posición con 's'.
	> b 64
	> s 0x80480

% ----------------------------------------------------- %
#Seeks
Para movernos dentro del espacio de memoria usaremos el comando 's'. Éste evaluará el argumento para resolver la dirección nueva.

Un seek relativo puede realizarse asi:
	> s+10                  > s++
	> s $$+10               > s--

Todos los seeks son registrados en un historial (s*) y podemos deshacer o rehacer los seeks con:
	> s main # seek a la flag 'main'
	> s-     # undo
	> s+     # redo

Mediante el separador '@' realizaremos un desplazamiento temporal. El separador '!' nos permite realizar un cambio de tamaño de bloque temporal.
	> x @ 0x80480
	> x @ 0x80480!10

% ----------------------------------------------------- %
#Escribiendo
Para editar un fichero debemos especificarlo con la flag '-w' que cargará el fichero en modo lectura y escritura.

Ensamblar un opcode
	> wa mov eax, 33

Escribir una cadena de texto:
	> w hello world\n

Escribir los contenidos de un fichero
	> wf dump.bin

Escribir un numero en little endian
	> wv 31337
	> p8 4

% ----------------------------------------------------- %
#Operaciones en el bloque (wo)
Usando 'wo' podemos modificar el bloque actual aplicandole una operación a cada byte del conjunto.

	> woa 1       # incrementa 1 a todos los bytes del bloque
	> wox 0x89    # aplicar xor con 0x89 sobre el bloque
	> wox 0x89    # aplicar xor con 0x89 sobre el bloque

Para generar secuencias de bytes repetidos por todo el bloque:

	> wb 01020304 # llena el bloque con esta secuencia

% ----------------------------------------------------- %
#Copy-Paste
El comando 'y' nos permite hacer 'yank & paste' o dicho de otra forma: Copiar y pegar los bytes deseados.
	> w Hello World
	> y 16
	> yp
	Hello World
	> ps@16
	Hello World
	> yy@16
	> ps@16
	> x 32

% ----------------------------------------------------- %
#Tuberias

Es posible usar pipes '|' para canalizar la salida del comando que ejecutemos a la entrada del programa de shell de la derecha.
	> pd | grep push

En este caso podemos reemplazar el 'grep' por el operador '~' que implementa un grep interno sin necesidad de ejecutar comandos de sistema (más portable).
	> pd~push

El grep interno nos permite contar las lineas y realizar greps por columnas o filas.

	> ~??        # muestra la ayuda del grep interno
	> pd~?       # 64 <- el numero de lines mostradas
	> pi~[0]     # muestra el mnemonico de cada opcode desensamblado
	> pi~call[1] # muestra las direcciones de destino de los calls
	> pi~call:1  # muestra el segundo call

% ----------------------------------------------------- %
#Interpretando comandos

Muchos comandos aceptan el subcomando '*', que, al igual que los programas con la flag -r muestran los datos en formato de comandos entendibles por radare.

Podemos interpretar la salida de un comando usando el prefijo '.', por ejemplo:

	> .!rabin2 -rs $FILE
	> .is*

Tambien podemos usar este comando para ejecutar scripts externos:

	> . script.rsc

% ----------------------------------------------------- %
# Macros
Las macros son unidades de scripting construidas por una lista de comandos separados por comas, es posible pasarle argumentos y evaluar las variables $0, $1, ..

	> (hola msg,?e hello $0,p8 16)
	> .(hola world)
	hello world

Con '@@' podemos ejecutar un comando para cada flag que encaje con un patrón.

	> .(test) @@ hit*

% ----------------------------------------------------- %
#Configuración

Las opciones son accesibles con el comando 'e' que evalua una expresion para leer y definir el valor de una entrada de la configuración.

Se clasifican por dominios y pueden contener texto, numeros o booleanos.

	e              # listar todas las variables
	e asm          # listar las variables del dominio 'asm'
	e??            # listar todas las variables y sus descripciones
	e?asm.arch     # muestra la descripcion de la variable
	e asm.arch     # muestra el valor de la variable
	e asm.bytes=0  # tambien es válido usar 'e asm.bytes=false'
	? ${asm.bits}  # mostrar el valor numerico de la variable asm.bits

Estos comandos pueden usarse desde el fichero '~/.radare2rc'. Y así definir una configuración predefinida en el arranque. Otra forma común de usarlo es mediante el uso de proyectos o incluyendo scripts con 'r2 -i'.

% ----------------------------------------------------- %
#Banderas

Las banderas (flags), son marcas que dejamos en el espacio de io. Estan compuestas por un nombre, una posición, una longitud y un comentario opcional.

Las flags se organizan dentro de flagspaces. El comando 'fs' nos permite listar, crear y seleccionar el flagspace actual.
	> f blah=0x80480400
	> fd 0x80480404
	blah+4

Las flags pueden ser accedidas por nombre en las expresiones:
	> f loop_begin=0x8048449
	> s loop_legin

Exportando y importando las flags
	> f* > flags.txt
	> . flags.txt

% ----------------------------------------------------- %
#Modo visual
El modo visual nos ofrece una cómoda forma de interactuar con radare mediante keybindings.

	> V

Para movernos utilizaremos las teclas 'hjkl'. Aunque las flechas tambien funcionan, es recomendable acostumbrarse a usarlas. En mayusculas nos moveremos más rapido ('HJKL').

Al igual que en la shell. La tecla '?' nos ofrecerá la ayuda.


% ----------------------------------------------------- %
#Teclas
Algunas de las acciones más comunes:

	0-9     saltar al jmp/call número..
	p P     cambiar entre modos de print (cmd.visual)
	y Y     copy paste
	:       introducir comando
	t       movernos por las flags
	e       cambiar las opciones
	g G     ir al principio y final del fichero
	c       activar/desactivar el modo cursor
	i       pasaremos a modo inserción. (cursor+tab)
	C       activar/desactivar los colores
	B       activa/desactiva el auto blocksize
	+ -     inc/dec el byte (cursor) o bloque
	mm ''   marcar posicion y saltar a ella

% ----------------------------------------------------- %
#Escritura visual

El modo visual nos ofrece varias formas de escribir bytes, strings o codigo ensamblador. 

 - 'i'nsertar text o hexpairs
 - usar + y - para modificar el valor de un byte
 - usando 'y' y 'Y' para copiar y pegar bytes
 - modo 'c'ursor para seleccionar un offset o rango

Mediante el comando VA podremos ensamblar codigo de forma dinamica. Tal como escribimos o borramos el codigo se ensamblará y se mostrará en el buffer. Esta funcionalidad puede sernos muy util cuando vayamos a parchear codigo ya existente.

La tecla 'A' nos abre un menú especial para ensamblar de modo interactivo.

% ----------------------------------------------------- %
#Ejercicios

Para asimilar con conceptos previamente expuestos realizaremos algunos ejercicios. No dudéis en preguntar cualquier duda que tengáis.

- solucionar crackme parcheando

- ensamblar en modo visual
