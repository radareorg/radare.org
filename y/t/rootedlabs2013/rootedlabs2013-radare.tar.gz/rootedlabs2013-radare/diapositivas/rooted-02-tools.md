% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(2/6)
% ----------------------------------------------------- %
#Herramientas

En esta sección se hará un repaso a las varias herramientas incluidas en radare2. Realizaremos varios ejercicios con el objetivo de comprender su uso y combinarlas para componer utilidades más complejas.

Podemos observar que todos los comandos terminan con un '2'. Esto permite la convivencia entre radare1 y radare2 en el sistema.

Cada herramienta implementa parte de las funcionalidades de las librerias, excepto 'r2' que las agrupa todas.

Mediante la flag '-h' obtendremos un resumen de las opciones y '-L' nos listará los plugins soportados.

Los grafos se generan en formato dot, para visualiarlos usaremos:
  'dot -Tpng -oa.png a.dot'

% ----------------------------------------------------- %
#rax2

Podriamos decir que rax2 es una calculadora multibase; permite el uso de expresiones matemáticas, cambio de endian, de base y formato.

Las expresiones pueden ser pasadas como argumentos o por stdin.

	$ rax2 3+0x80      $ rax2 0x80+3          $ echo 0x80+3 | rax2 
	0x83               131                    131
	
	$ rax2 -s 4142     $ rax2 -S AB           $ rax2 -S < bin.foo
	AB                 4142                   ...
	
	$ rax2 -e 33       $ rax2 -e 0x21000000   $ rax2 -k 90203010
	0x21000000         33                     +--[0x10302090]---+

Desde r2 podemos evaluar estas expresiones mediante el comando '? '

% ----------------------------------------------------- %
#rahash2
Los dispositivos forenses de captura de discos suelen calcular el hash los datos con tal de asegurar que no han sido alterados durante su manipulación.

Esta herramienta nos permite calcular checksums de ficheros o strings.

	$ rahash2 -L                 # listar todos los algoritmos
	$ rahash2 -qa crc32 /bin/ls  # calculate crc32 of given file
	$ rahash2 -a entropy -Bb 512 /bin/ls # calculate entropy of file every 512 bytes
	$ rahash2 -ks "hello world"  # show randomkey art for given string

Podemos especificar el tamaño de bloque (-b) y usar un checksum incremental (-B), con tal de calcular el resultado total de golpe o por bloques. Esto puede sernos util para averiguar que partes de un firmware o disco han sido modificados de una version a otra.

rahash2 tambien permite realizar calculos de entropia, distancia de hamming, porcentaje de caracteres alfanumericos, ..
	[ejercicio: buscar que byte se ha modificado]

% ----------------------------------------------------- %
#radiff2

Compara dos ficheros a nivel de byte con soporte de cambios con desplazamiento. Tambien es posible calcular un bindiffing a nivel del analysis de codigo de los dos programas '-C'.

	$ radiff2 a b # repetir ejercicio anterior 

Tambien nos permite calcular la distancia de texto '-s' entre dos documentos o cadenas de texto.

Mostrar las diferencias de codigo analizado:
	$ radiff2 -C /bin/true /bin/false

Mostrar que bytes cambian de un fichero a otro de tamaños distintos:
	$ radiff2 -pd /bin/true /bin/false

% ----------------------------------------------------- %
#rasm2
Este programa permite ensamblar y desensamblar multitud de arquitecturas.
	$ rasm2 -h     # mostrar ayuda
	$ rasm2 -L     # listar plugins

Ensamblando
	$ rasm2 -a x86 -b 32 'mov eax, 33'
	b821000000
	$ echo 'push eax;nop' | rasm2 -f -
	509090
	$ rasm2 -a x86 -b 32 -f file.asm

Desensamblando:
	$ rasm2 -a x86 -b 32 -d '90'
	nop
	$ echo 77 | rasm2 -dBf -
	aaa
	aaa

% ----------------------------------------------------- %
#rafind2

Este programa nos permite realizar busquedas de cadenas de texto o bytes, con posibilidad de aplicarles una máscara binaria.

Los resultados se muestran de forma cómoda para ser procesada por otras aplicaciones. Mediante las flags -Z y -X podemos visualizar las cadenas de texto y un hexdump de los resultados.

Por ejemplo:
	$ rafind2 -Zs lib /bin/ls | grep dy
	0x1649 lib/dyld
	0x1745 lib/libncurses.5.4.dylib
	0x177d lib/libSystem.B.dylib
	...


% ----------------------------------------------------- %
#ragg2

Permite compilar shellcodes, y aplicarle un encoder y paddings. Tambien permite generar binarios o ejecutarlas para comprobar que funcionan correctamente.

ragg2-cc nos permite compilar código C para generar shellcodes.

Crear una shellcode para linux-x86-32 que ejecute /bin/sh:
	$ ragg2 -a x86 -b 32 -k linux -i exec

Crear una shellcode desde C:
	$ cat a.c
	int main() { write(1,"Hi\n", 3); exit(1); }
	$ ragg2-cc -x a.c
	e90000000083ec0ce800000000588d882a000000b804000000606a03516a0150cd80...
	$ ragg2-cc a.c
	$ ./a.c.bin
	Hi

% ----------------------------------------------------- %
#rabin2

Parsea binarios y extrae información de simbolos, imports, strings, ...
	$ echo $(rabin2 -L|awk '{print $2}')
	dex elf elf64 fs java mach0 mach064 mz p9 pe pe64 rar dyldcache fatmach0

En caso de ser un binario gordo (fat). Deberemos usar las flags -a y -b para especificar el sub-binario.

Mediante la flag '-c' podemos crear binarios 'tiny'.o
	$ rabin2 -c elf:cc trap
	$ ./trap
	Trace/BPT trap

Extraer la información del binario en formato de comandos de radare con -r
	$ rabin2 -risSeI /bin/ls > ls.txt
	$ r2 -i ls.txt /bin/ls

% ----------------------------------------------------- %
#rarun2

Rarun nos permite definir entornos de ejecución, donde podemos especificar un chroot, diferente UID, ficheros como stdin, argumentos, conexiones de red, timeouts...

Algunos casos de uso:
 - depurar programas delicados
 - test suite
 - fuzzing
 - ..

	$ rarun2 timeout=3 program=/bin/cat         # matar el cat despues de 3 segundos
	$ rarun2 listen=9999 program=/bin/sh        # bindear una shell por tcp
	$ rarun2 stdin=input.txt program=./crackme  # especificar entrada desde un fichero
	$ rarun2 stdin=/etc/services program=/usr/bin/grep arg1=pop

% ----------------------------------------------------- %
#r2

Finalmente nos encontramos con la herramienta principal de radare2. Construida sobre 'r_core' constituye la pieza central del resto de librerias y permite la interacción mediante la linea de comandos, scripts o modo visual y web.

Cargar un fichero sin analizarlo:
	$ r2 -n /bin/ls
Lanzando un script:
	$ cat make-test.r
	x;pi 4;s+33
	$ r2 -qi make-test.r -w test 
Recargando un proyecto
	$ r2 -p blah
Abrir en modo escritura
	$ r2 -w program

% ----------------------------------------------------- %
#Jugando con tuberias
Los comandos podemos unirlos facilmente con tal de crear nuevas herramientas o automatizar ciertas tareas.

	$ ( rafind2 -rslib ; echo 'w lob@@hit*' ) | r2 -qw ls
	$ ragg2 -ri exec > shellcode
	$ r2 -nqfcpDi shellcode | grep syscall
	> pd > disasm.txt
	> !grep mov disasm.txt | grep eax
	> !!grep mov disasm.txt~eax
	> pdf~mov| grep eax

Comandos de ayuda: !? ~??

% ----------------------------------------------------- %
#Dudas?

Hasta aqui el resumen de todas las herramientas incluidas en radare2.

A partir de ahora nos centraremos en usar 'radare2', y dejaremos el resto a parte. Si tenéis alguna duda.. este es vuestro momento.
