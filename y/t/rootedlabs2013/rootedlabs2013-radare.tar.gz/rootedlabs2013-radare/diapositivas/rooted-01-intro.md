% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(1/6)
% ----------------------------------------------------- %
#RootedLabs 2013

Bienvenidos al taller de ingeniería inversa con radare2.

Para seguir el taller es necesario tener configurada la red y instalar la máquina virtual y un putty.

Al entrar usaremos: root/radare y seguiremos los pasos descritos en el README

En el primer arranque deberán definir una contraseña para el usuario 'radare'

Para realizar el taller usaremos la terminal en todo momento, asi que el alumno debe saber manejarse por la shell.
% ----------------------------------------------------- %
#Test de nivel

- Alguien sabe que es radare?

% ----------------------------------------------------- %
#Test de nivel

- Alguien sabe que es radare?

- Y la ingenieria inversa?
% ----------------------------------------------------- %
#Test de nivel

- Alguien sabe que es radare?

- Y la ingenieria inversa?

- Cómo os manejais en la shell de un sistema *nix?


% ----------------------------------------------------- %
#Introducción

Radare es un proyecto con más de 7 años de desarrollo a sus espaldas, empezaremos viendo su historia y entenderemos las filosofias aplicadas en su desarrollo.

En este taller aprenderemos el uso de la herramienta a través de varios ejercicios prácticos que nos ayudarán a entender mejor el funcionamiento tanto del programa como del elemento que estemos analizando.

Procuraremos centrarnos en la ingeniería inversa, aunque mostraremos por encima las otras caras de radare2 cómo analisis forense, la depuración, fuzzing, exploiting, entre otras.

% ----------------------------------------------------- %
#Qué es el reversing?

La ingeniería inversa es el proceso por el cual se pretende descubrir el funcionamiento técnico de algo a partir del análisis de sus resultados, estructuras de datos, funciones y operaciones.

Este curso se enfoca al reversing de binarios (programas ejecutables) con el objetivo de entender su funcionamiento y manipularlo para adaptarlo a nuestras "necesidades".

Radare es un framework de reversing que nos ofrece varias herramientras accesibles a traves de programas y librerias con bindings para multitud de lenguajes de scripting.

% ----------------------------------------------------- %
#Historia

Radare nació en 2006 como una herramienta forense; un editor hexadecimal de 64 bits para hacer busquedas en discos duros.

Pronto el proyecto creció permitiendo desensamblar codigo maquina de varias arquitecturas, depurar en windows, linux y mac, scripting..

Despues de 4 años creciendo decidí reescribirlo desde cero con tal de solventar varias limitaciones implicitas en el diseño monolítico de la primera versión.

Así nació radare2, implementado sobre un conjunto de librerias, permitiendo un scripting completo a través de las APIs, mejor rendimiento y calidad de codigo.

% ----------------------------------------------------- %
#Capacidades

radare2 es un framework que nos ofrece:

- ensamblador / desensamblador
- editor hexadecimal por bloques de 64bits
- calcular checksums por bloques
- maneja transparentemente procesos, discos, ficheros, ram, ..
- montar sistemas de archivos (fat, ntfs, ext2, ..)
- analizar binarios de windows, linux, mac, java, dalvik, ..
- depurador (w32, linux, mac, ios)
- busqueda de diferencias binarias
- herramientas para la creacion de shellcodes
- soporte para varios lenguajes de scripting (python, js, ..)

% ----------------------------------------------------- %
#Filosofia

Desde sus inicios ha sido un proyecto personal, aunque ha recibido numerosas contribuciones y durante este tiempo la comunidad ha crecido, alimentando el proyecto con ideas, nuevas funcionalidades.

Lo distribuyo bajo licencia LGPL3, lo cual permite su uso para proyectos propietarios, aunque obliga a publicar cualquier modificación de las librerias.

Casi todas las funcionalidades se pueden extender con plugins o scripts, con lo que todos los usuarios se benefician de las mejoras que realice cualquier proyecto que use el framework.

Muchas ideas han sido basadas en conceptos de UNIX. Como la ortogonalidad, las pipes, filtros, todo el i/o de trata como un fichero, ... 

% ----------------------------------------------------- %
#Aprendizaje

La curva de aprendizaje de radare es parecida a la de otros programas de UNIX.

Al principio los comandos parecen complicados, pero conforme vayamos aprendiendo la logica detrás de cada caracter iremos relacionando conceptos más rapidamente.

La shell de radare tiene muchos parecidos con las shells posix de los sistemas *NIX, es por esto que conocerla nos facilitará el aprendizaje.

Ya que el desarrollo es muy activo es recomendable usar la versión de git y entrar en el irc para enterarse de novedades o reportar ideas/fallos/...
% ----------------------------------------------------- %
#Desarrollo

R2 está escrito en C y compila en multitud de plataformas sin necesidad de ninguna dependencia más que make, una shell posix y un compilador.

El codigo se publica en un repositorio git (hay mirrors) y se intenta cortar una versión estable cada 6 meses. Aunque suele ser cada 300 commits.

Existe una test suite que pretende detectar errores de funcionamiento pero aún no hay suficientes tests cómo para verificar todas las opciones del software.

Para generar los bindings desarrollé un programa llamado 'valabind' que permite generar bindings para python-ctypes, nodejs o swig (lua, perl, ...) a partir de las descripciones de las apis en formato vapi (del lenguaje Vala)

La mejor documentación siempre es el código fuente. La documentación de la api se genera a partir de las interfaces Vapi usando valadoc.

% ----------------------------------------------------- %
#Instalando desde GIT

Los alumnos aprenderán a instalar radare2 desde su repositorio con tal de poder seguir el taller usando la ultima versión en desarrollo.

	$ git clone git://github.com/radare/radare2
	$ cd radare2
	$ ./configure --prefix=/usr
	$ make
	$ sudo make symstall
	$ r2 -v
	radare2 0.9.3git @ darwin-little-x86-64 build 2013-02-01
	commit: dc2690e5294a201aeef96a038ddf152fc9f69257

Aunque GNU/Linux y OSX sean las principales plataformas soportadas, tambien es posible usar radare2 desde cualquier sistema BSD o Windows.

% ----------------------------------------------------- %
#Detalles
El proceso de instalación es el común de la mayoria de aplicaciones libres, aunque cabe destacar ciertos detalles:

- usa acr (en vez de autoconf)

- make symstall instala con symlinks (más rápido y util para desarrollar sin instalar cada vez)

- sys/install.sh instala con symlinks a /usr, es comodo usar este metodo si estas desarrollando (cada compilacion no requiere ser instalada)

- make uninstall/purge - para desinstalar la versión actual o todas las instalaciones previas.

- en el directorio sys/ existen varios scripts que facilitan las compilaciones nativas, de windows o android.

% ----------------------------------------------------- %
#Ejercicios y dudas
En esta primera parte del curso lo importante es llegar a tener una instalación funcional de radare2. Punto indispensable para seguir el resto de apartados.

Instalación fuera de /usr/bin
	$ ./configure --prefix=/opt/r2 --with-rpath
	$ make
	$ sudo make symstall
	$ export PATH=/opt/r2/bin:$PATH

Limpiar sistema de instalaciones previas
	$ sudo make purge

Crosscompilar para windows:
	$ sys/mingw32.sh

Crosscompilar para android:
	$ sys/android-arm.sh

% ----------------------------------------------------- %
