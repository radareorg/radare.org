% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(6/6)
% ----------------------------------------------------- %
#Interfaz gráfica y cloud

Despues de haber escrito unas 5 interfaces graficas distintas para radare y viendo cómo de dificil es conseguir desarrolladores que quieran implicarse en programar interficies gráficas decidí apostar por la web.

 - HTML/CSS/JS son tecnologias muy comunes y estandarizadas
 - adaptado a multiples tamaños de pantallas (responsive design)
 - podemos lanzar un servidor web de radare en un embedido y depurar desde el desktop
 - multiples clientes trabajando a la vez sobre la misma sesión

gradare, bokken, ragui, r2w, r2w2...

% ----------------------------------------------------- %
#El servidor web

Radare viene con una implementación simplista de un client y un servidor http.
- HTTP 1.0 singlethread
- 600LOC
- get/post
- upload files
- ajax
- servir ficheros estaticos
- ejecutar comandos en /cmd/...

Y la forma de lanzarlo es utilizando '='. Este comando nos permite conectar radare con otros radares en local o remoto mediante los protocolos rap o http.

La interfaz es html estatico, y los contenidos se generan dinamicamente con peticiones ajax a /cmd/ para extraer información del core.

% ----------------------------------------------------- %
#Iniciando el servidor web

Para arrancar el servidor web, podemos 

	$ r2 -qc=h /bin/ls         # carga el servidor
	$ r2 -qc'=h 9999' /bin/ls  # escucha en el puerto 9999
	$ r2 -qc=H /bin/ls         # carga el servidor y el navegador

Para conectarnos:

	$ firefox http://localhost:9090
	$ r2 -C localhost:9090
	$ r2 -c=+http://localhost:9090/cmd/
	$ echo x | r2 -C localhost:9090
	> =
% ----------------------------------------------------- %
#JSON
Recientemente se está añadiendo el subcomando 'j' en varios comandos. Funciona de forma parecida a '*', sólo que en vez de mostrar los datos en forma de comandos de radare, se muestra en formato JSON.

De esta forma es muy fácil acceder a los datos de radare desde javascript.

	> iIj
	{"type":"mach0","class":"MACH064","endian":"little","machine":
	"x86 64 all","arch":"x86","os":"darwin","lang":"c","pic":false,
	"va":true,"bits":64,"stripped":false,"static":false,"linenums":
	false,"syms":false,"relocs":false}

% ----------------------------------------------------- %
#Scripting

Python y Javascript són los lenguajes de scripting oficiales de radare2, aunque existen bindings para muchos otros lenguajes.

La forma de interactuar desde javascript es haciendo peticiones AJAX a /cmd/<...> y el output que seria el output del comando, podemos parsearlo cómo texto o json.

* bindings *

% ----------------------------------------------------- %
#Futuro

Es bastante probable que el desarrollo del GUI continue siendo HTML5, aunque no necesariamente usando el framework actual (enyo).

El cloud (cloud.rada.re) nos permitirá publicar sesiones de radare, para que otros usuarios puedan colaborar en tiempo real.

Actualmente sirve cómo sitio de demostración.

% ----------------------------------------------------- %
#Demo y ejercicios

* go *

% ----------------------------------------------------- %
#EOF
