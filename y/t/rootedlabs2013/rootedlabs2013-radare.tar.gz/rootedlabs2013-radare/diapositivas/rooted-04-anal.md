% RootedLabs 2013
##Introducción al reversing con r2
[img/r2logo2.png|-bordercolor white -border 360x150x10x10]
@pancake <pancake@nopcode.org>
@(4/6)
% ----------------------------------------------------- %
#Analizando binarios

Una de los usos más interesantes de radare es para realizar analisis estatico sobre programas (independientemente de sistema operativo y arquitectura). Esto nos permitirá comprender mejor el funcionamiento del programa que queramos analizar.

El motor de análisis de radare permite generar grafos de bloques básicos, definir funciones, identificar saltos, referencias a variables, incremento de la pila, argumentos...

% ----------------------------------------------------- %
#Analizando cabeceras
Los programas se estructuran de la siguiente forma:

	+---------------+
	|     magic     |  - file type
	+---------------+
	|     extra     |  - syms, imports, ...
	+---------------+
	|     code      |  - program code
	+---------------+
	|     data      |  - program data
	+---------------+

rabin2 nos permite recoger toda esta información de forma generica, sin importar el formato del fichero (siempre que este soportado) Pero tambien podemos acceder a ella a través del comando 'i' de la shell de r2.
% ----------------------------------------------------- %
#Mostrando información del binario

Aqui algunos ejemplos de como recoger información del programa.

	$ rabin2 -I foo
	$ rabin2 -rI foo
	$ rabin2 -s foo

Usando el comando 'i' podemos importar la información del binario.
	> .ia*

	io : open file              ic : classes
	ia : show all info          id : debug info
	ie : entrypoints            ih : headers
	ii : imports                iI : file info
	is : symbols                iS : sections
	iz : strings                iaj: json

% ----------------------------------------------------- %
#Mostrando datos con formato

Mediante el comando 'pf' definiremos una cadena de formato la cual queremos usar para visualizar los datos del bloque actual.

Nos permite especificar el endian, el tipo de variable, nombre de la variable, generar arrays de estructuras, punteros, ...

Usaremos el comando 'C' para definir un formato que va a ser usado cuando se muestre el desensamblado.

	pf?      # mostrar la ayuda
	Cf 12 3xxi id

% ----------------------------------------------------- %
#Añadir comentarios

En ocasiones, cuando estemos analizando un programa grande, nos será de gran ayuda poder dejar anotaciones al lado del desensamblado.

Los comentarios pueden estar asociados a un offset (CC) o a una flag (fC).

	> CC good boy @ main+0x80
	> fC bad boy @ sym.fail

Estas anotaciones pueden importarse y exportarse usando proyectos o pipes.
	$ r2 -p test /bin/ls    # crear proyecto nuevo
	$ r2 -p test            # cargar proyecto
	> CC* > comments.txt    # exportar comentarios
	> . comments.txt        # importar comentarios

% ----------------------------------------------------- %
#Desensamblando

Existen varias formas de desensamblar (pd?) y el formato puede configurarse mediante 'e asm.'.

	> pi 4        # desensamblar 4 instrucciones
	> pd 4        # igual que el anterior, pero más completo
	> pDi 4       #
	> e asm.pseudo = true
	> e asm.arch = arm
	> e asm.bits = 64
	* Cx

% ----------------------------------------------------- %
#Ficheros mágicos

El comando 'file' de *NIX nos permite identificar el tipo de archive comparando la cabecera contra una base de datos de definiciones (magic database).

r2 incorpora en r_magic la implementación de OpenBSD y podemos usara con el comando 'pm' para identificar el tipo de dato en el cual nos encontramos.

	> pm
	> pm elf
	> / ELF

* ejercicio: buscar un elfo en un pajar

% ----------------------------------------------------- %
#Cálculos estadisticos

El analisis de datos pretende ofrecernos agregar la información cruda en resultados utiles para el reverser.

- 'pz' zoom view, configurable mediante zoom.* , 'pz?' para ayuda
- 'p=' muestra graficas de barras de entropia y numero de caracteres alfanumericos
- rahash2 -a entropy -B -b 512 /bin/ls

Entropia:
 - cero o muy bajo: (vacio)
 - medio de entropia: texto plano, datos
 - alto: codigo
 - muy alto: comprimido o cifrado

% ----------------------------------------------------- %
#Buscando cadenas

El comando '/' realiza busquedas de strings o cadenas binarias dentro de un rango de offsets

% ----------------------------------------------------- %
#Comparando datos

- cargar 2 archivos a la vez (io maps!)
- comparando en memoria

% ----------------------------------------------------- %
#Analizando opcodes

Podemos extraer información de los opcodes mediante el comando 'ao' o 'a8'. Veamos 

	> pi 1
	call dword 0x7fff5fc013b3
	> ao 1
	addr: 0x7fff5fc0104d
	size: 5
	type: 8 (call)
	eob: 0
	jump: 0x7fff5fc013b3
	fail: 0x7fff5fc01052

En caso de no querer analizar el opcode de la posición actual podemos especificar los bytes del opcode para que este sea analizado.

	> a8 c3cc90 @ 0x80480240

% ----------------------------------------------------- %
#Analizando codigo
El motor de análisis de radare permite buscar y definir funciones. Podemos renombrarlas y cambiar sus propiedades mediante los subcomandos de 'af'.

Estos son algunos de los comandos que usaremos:

	> aa        # analizar desde entrypoint y simbolos
	> af        # analizar desde el offset actual
	> afr       # renombrar función
	> af-$$     # borrar funcion en el offset actual
	> pdf       # desensambla la función entera
	> af      # analyzar función en el offset actual
	> afi $$  # mostrar informacion de la funcion
	> pdf     # desensamblar solo la función

% ----------------------------------------------------- %
#Generando un grafo
A partir de la información analizada de las funciones podemos generar grafos en formato Dot que nos muestren los caminos de ejecución.

	> af
	> ag $$ > a.dot
	> agv $$
	> !dot -Tpng -o a.png a.dot

Tambien podemos generar un grafo de las llamadas entre funciones (callgraph)

	> agc $$ > a.dot

* nota * con 'dtc/dtg' podemos realizar runtime callgraphs.

% ----------------------------------------------------- %
#Referencias
Buscar en que parte del programa se accede a cierta string, es un caso de uso bastante común en el reversing. Desensamblado con 'pd' se nos mostrarán las referencias de codigo y datos:

Si no queremos depender del motor de code analysis, podemos realizar una busqueda que encaje con el opcode desensamblado y que referencie la dirección de esta.

	> s main
	> af
	> ? str.HelloWorld
	0x100000f2e
	> pd~0x100000f2e

* ejercicio parchear crackme con xrefs *

% ----------------------------------------------------- %
#Extra: Hints

El usuario puede modificar la información que devuelve el motor de análisis usando el comando 'ah'. De esta forma podemos corregir errores del desensamblador o redefinir los mnemonicos a mano.

	> ahl 10            # definir la longitud del opcode
	> aho push GOODBOY  # cambiar el opcode en el desensamblado
	> aha arm 512       # especificar asm.arch en los siguientes 512 bytes
	> ahb

Redefinir la string del opcode puede sernos util para mejorar la legibilidad.

* ejercicio * files/antidis

% ----------------------------------------------------- %
#Y más...

Las próximas versiones de radare2 pretenden mejorar cuantitativamente el análisis de código estático. Con representaciones completas y multi-arquitectura de todos los opcodes, mejor rendimiento y menor consumo de memoria.

Aunque el soporte actual no nos permita emular código, es suficiente para muchas tareas.

Si teneis preguntas... Ahora es vuestro momento!
